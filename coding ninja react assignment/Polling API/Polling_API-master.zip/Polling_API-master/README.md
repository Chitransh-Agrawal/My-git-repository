# Polling_API
a polling api made in node.js backend and with mongodb. you can add, delete, view question also can have option for them with upvotes

<html>
  <body>
    <h2>Polling_API</h2>
    <h3>Steps for setting up in local machine</h3>
     <ul>  
       <li>clone repository using <code>git clone :REPO_URL </code> and have all node modules which are required</li>
        <li>run command <code>npm start</code> from inside <code>root</code> directory.</li>
     </ul>
  </body>
</html>
